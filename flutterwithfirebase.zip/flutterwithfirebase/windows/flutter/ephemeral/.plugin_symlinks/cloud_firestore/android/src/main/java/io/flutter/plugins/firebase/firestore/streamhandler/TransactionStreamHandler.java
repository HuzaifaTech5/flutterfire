/*
 * Copyright 2022, the Chromium project authors.  Please see the AUTHORS file
 * for details. All rights reserved. Use of this source code is governed by a
 * BSD-style license that can be found in the LICENSE file.
 */

package io.flutter.plugins.firebase.firestore.streamhandler;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.FirebaseFirestoreException.Code;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.Transaction;
import com.google.firebase.firestore.TransactionOptions;
import io.flutter.plugin.common.EventChannel.EventSink;
import io.flutter.plugin.common.EventChannel.StreamHandler;
import io.flutter.plugins.firebase.firestore.FlutterFirebaseFirestoreTransactionResult;
import io.flutter.plugins.firebase.firestore.GeneratedAndroidFirebaseFirestore;
import io.flutter.plugins.firebase.firestore.utils.ExceptionConverter;
import io.flutter.plugins.firebase.firestore.utils.PigeonParser;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class TransactionStreamHandler implements OnTransactionResultListener, StreamHandler {

  /** Callback when the transaction has been started. */
  public interface OnTransactionStartedListener {
    void onStarted(Transaction transaction);
  }

  /** Callback when Dart cancels the transaction event stream. */
  public interface OnTransactionCancelledListener {
    void onCancelled(String transactionId);
  }

  final OnTransactionStartedListener onTransactionStartedListener;
  final OnTransactionCancelledListener onTransactionCancelledListener;
  final FirebaseFirestore firestore;
  final String transactionId;
  final Long timeout;

  final Long maxAttempts;

  public TransactionStreamHandler(
      OnTransactionStartedListener onTransactionStartedListener,
      OnTransactionCancelledListener onTransactionCancelledListener,
      FirebaseFirestore firestore,
      String transactionId,
      Long timeout,
      Long maxAttempts) {
    this.onTransactionStartedListener = onTransactionStartedListener;
    this.onTransactionCancelledListener = onTransactionCancelledListener;
    this.firestore = firestore;
    this.transactionId = transactionId;
    this.timeout = timeout;
    this.maxAttempts = maxAttempts;
  }

  final Semaphore semaphore = new Semaphore(0);
  private GeneratedAndroidFirebaseFirestore.InternalTransactionResult resultType;
  private List<GeneratedAndroidFirebaseFirestore.InternalTransactionCommand> commands;

  final Handler mainLooper = new Handler(Looper.getMainLooper());

  @Override
  public void onListen(Object arguments, EventSink events) {
    firestore
        .runTransaction(
            new TransactionOptions.Builder().setMaxAttempts(maxAttempts.intValue()).build(),
            transaction -> {
              onTransactionStartedListener.onStarted(transaction);

              Map<String, Object> attemptMap = new HashMap<>();
              attemptMap.put("appName", firestore.getApp().getName());

              mainLooper.post(() -> events.success(attemptMap));

              try {
                if (!semaphore.tryAcquire(timeout, TimeUnit.MILLISECONDS)) {
                  // Throw a non-FirebaseFirestoreException so the Android SDK
                  // does not retry or commit. Returning a failed result object
                  // makes apply() succeed, which commits and then crashes a later
                  // transaction.get (see #18666).
                  throw new RuntimeException(
                      new FirebaseFirestoreException("timed out", Code.DEADLINE_EXCEEDED));
                }
              } catch (InterruptedException e) {
                throw new RuntimeException(
                    new FirebaseFirestoreException("interrupted", Code.DEADLINE_EXCEEDED));
              }

              if (commands.isEmpty()) {
                return FlutterFirebaseFirestoreTransactionResult.complete();
              }

              if (resultType
                  == GeneratedAndroidFirebaseFirestore.InternalTransactionResult.FAILURE) {
                return FlutterFirebaseFirestoreTransactionResult.complete();
              }

              for (GeneratedAndroidFirebaseFirestore.InternalTransactionCommand command :
                  commands) {
                DocumentReference documentReference = firestore.document(command.getPath());

                switch (command.getType()) {
                  case DELETE_TYPE:
                    transaction.delete(documentReference);
                    break;
                  case UPDATE:
                    {
                      Map<Object, Object> rawData = Objects.requireNonNull(command.getData());
                      Map<FieldPath, Object> updateData = new HashMap<>();
                      for (Object key : rawData.keySet()) {
                        if (key instanceof String) {
                          updateData.put(FieldPath.of((String) key), rawData.get(key));
                        } else if (key instanceof FieldPath) {
                          updateData.put((FieldPath) key, rawData.get(key));
                        }
                      }
                      FieldPath firstFieldPath = updateData.keySet().iterator().next();
                      Object firstObject = updateData.get(firstFieldPath);
                      ArrayList<Object> flattenData = new ArrayList<>();
                      for (FieldPath fieldPath : updateData.keySet()) {
                        if (fieldPath.equals(firstFieldPath)) {
                          continue;
                        }
                        flattenData.add(fieldPath);
                        flattenData.add(updateData.get(fieldPath));
                      }
                      transaction.update(
                          documentReference, firstFieldPath, firstObject, flattenData.toArray());
                      break;
                    }
                  case SET:
                    {
                      GeneratedAndroidFirebaseFirestore.InternalDocumentOption options =
                          Objects.requireNonNull(command.getOption());
                      SetOptions setOptions = null;

                      if (options.getMerge() != null && options.getMerge()) {
                        setOptions = SetOptions.merge();
                      } else if (options.getMergeFields() != null) {
                        List<List<String>> fieldList =
                            Objects.requireNonNull(options.getMergeFields());
                        List<FieldPath> fieldPathList = PigeonParser.parseFieldPath(fieldList);

                        setOptions = SetOptions.mergeFieldPaths(fieldPathList);
                      }

                      @SuppressWarnings("unchecked")
                      Map<String, Object> data =
                          (Map<String, Object>)
                              (Map<?, ?>) Objects.requireNonNull(command.getData());

                      if (setOptions == null) {
                        transaction.set(documentReference, data);
                      } else {
                        transaction.set(documentReference, data, setOptions);
                      }

                      break;
                    }
                }
              }
              return FlutterFirebaseFirestoreTransactionResult.complete();
            })
        .addOnCompleteListener(
            task -> {
              final HashMap<String, Object> map = new HashMap<>();
              if (task.getException() != null || task.getResult().exception != null) {
                final @Nullable Exception exception =
                    task.getException() != null ? task.getException() : task.getResult().exception;
                map.put("appName", firestore.getApp().getName());
                map.put("error", ExceptionConverter.createDetails(exception));
              } else if (task.getResult() != null) {
                map.put("complete", true);
              }

              mainLooper.post(
                  () -> {
                    events.success(map);
                    events.endOfStream();
                  });
            });
  }

  @Override
  public void onCancel(Object arguments) {
    semaphore.release();
    // FlutterFirebaseFirestorePlugin passes null when disposing all listeners and clears the
    // listener maps itself. A non-null value identifies Dart's EventChannel cancellation.
    if (arguments != null) {
      onTransactionCancelledListener.onCancelled(transactionId);
    }
  }

  @Override
  public void receiveTransactionResponse(
      GeneratedAndroidFirebaseFirestore.InternalTransactionResult resultType,
      List<GeneratedAndroidFirebaseFirestore.InternalTransactionCommand> commands) {
    this.resultType = resultType;
    this.commands = commands;
    semaphore.release();
  }
}
