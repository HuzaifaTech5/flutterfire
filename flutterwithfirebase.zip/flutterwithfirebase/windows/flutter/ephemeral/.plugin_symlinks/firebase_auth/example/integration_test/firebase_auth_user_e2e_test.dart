// Copyright 2020, the Chromium project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'test_utils.dart';

/// Guards against a dropped `verifyPhoneNumber` callback hanging the whole
/// suite: a missing callback fails the test instead of burning the job
/// timeout. Generous because this is a multi-step phone auth flow.
const _completerTimeout = Duration(seconds: 60);

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group(
    '$User',
    () {
      String email = generateRandomEmail();

      group(
        'getIdToken()',
        () {
          test('should return a token', () async {
            // Setup
            User? user;
            UserCredential userCredential;

            userCredential =
                await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            user = userCredential.user;

            // Test
            String? token = await user!.getIdToken();

            // // Assertions
            expect(token?.length, greaterThan(24));
          });

          test('should return a token using `getIdToken()` after sign in',
              () async {
            // Demonstrate fix for this issue works: https://github.com/firebase/flutterfire/issues/11297
            String email = generateRandomEmail();

            final userCredential =
                await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );

            String? token = await userCredential.user!.getIdToken(true);

            expect(token?.length, greaterThan(24));
          });

          test('should return a token using `getIdTokenResult()` after sign in',
              () async {
            // Demonstrate fix for this issue works: https://github.com/firebase/flutterfire/issues/11297
            String email = generateRandomEmail();

            final userCredential =
                await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );

            IdTokenResult result =
                await userCredential.user!.getIdTokenResult(true);

            expect(result.token?.length, greaterThan(24));
          });

          test('should catch error', () async {
            // Setup
            final userCredential =
                await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            final user = userCredential.user!;

            // needed for method to throw an error
            await FirebaseAuth.instance.signOut();

            try {
              // Test
              await user.getIdToken();
            } on FirebaseAuthException catch (_) {
              return;
            } catch (e) {
              fail('should have thrown a FirebaseAuthException error');
            }
            fail('should have thrown an error');
          });
        },
        skip: !kIsWeb &&
            (defaultTargetPlatform == TargetPlatform.windows ||
                defaultTargetPlatform == TargetPlatform.macOS),
      );

      group('getIdTokenResult()', () {
        test(
          'should return a valid IdTokenResult Object',
          () async {
            // Setup
            final userCredential =
                await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            final user = userCredential.user!;

            // Test
            final idTokenResult = await user.getIdTokenResult();

            // Assertions
            expect(idTokenResult.token.runtimeType, equals(String));
            expect(idTokenResult.authTime.runtimeType, equals(DateTime));
            expect(idTokenResult.issuedAtTime.runtimeType, equals(DateTime));
            expect(idTokenResult.expirationTime.runtimeType, equals(DateTime));
            expect(idTokenResult.token!.length, greaterThan(24));
            expect(idTokenResult.signInProvider, equals('password'));
          },
          skip: !kIsWeb &&
              (defaultTargetPlatform == TargetPlatform.windows ||
                  defaultTargetPlatform == TargetPlatform.macOS),
        );
        // TODO add custom claims and tenant id tests for id token result
      });

      group(
        'linkWithCredential()',
        () {
          test('should link anonymous account <-> email account', () async {
            await FirebaseAuth.instance.signInAnonymously();
            final currentUID = FirebaseAuth.instance.currentUser!.uid;

            final linkedUserCredential =
                await FirebaseAuth.instance.currentUser!.linkWithCredential(
              EmailAuthProvider.credential(
                email: email,
                password: testPassword,
              ),
            );

            final linkedUser = linkedUserCredential.user!;
            expect(linkedUser.email, equals(email));
            expect(
              linkedUser.email,
              equals(FirebaseAuth.instance.currentUser!.email),
            );
            expect(linkedUser.uid, equals(currentUID));
            expect(linkedUser.isAnonymous, isFalse);
          });

          test('should error on link anon <-> email if email already exists',
              () async {
            // Setup

            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            await FirebaseAuth.instance.signInAnonymously();

            // Test
            try {
              await FirebaseAuth.instance.currentUser!.linkWithCredential(
                EmailAuthProvider.credential(
                  email: email,
                  password: testPassword,
                ),
              );
            } on FirebaseAuthException catch (e) {
              // Assertions
              expect(e.code, 'email-already-in-use');
              expect(
                e.message,
                'The email address is already in use by another account.',
              );

              // clean up
              await FirebaseAuth.instance.currentUser!.delete();
              return;
            }

            fail('should have thrown an error');
          });

          test(
            'should link anonymous account <-> phone account',
            () async {
              await FirebaseAuth.instance.signInAnonymously();

              Future<String> getVerificationId() {
                Completer completer = Completer<String>();

                unawaited(
                  FirebaseAuth.instance.verifyPhoneNumber(
                    phoneNumber: testPhoneNumber,
                    verificationCompleted: (PhoneAuthCredential credential) {
                      fail('Should not have auto resolved');
                    },
                    verificationFailed: (FirebaseException e) {
                      fail('Should not have errored: $e');
                    },
                    codeSent: (String verificationId, int? resetToken) {
                      completer.complete(verificationId);
                    },
                    codeAutoRetrievalTimeout: (String foo) {},
                  ),
                );

                return completer.future
                    .timeout(_completerTimeout)
                    .then((value) => value as String);
              }

              String storedVerificationId = await getVerificationId();

              await FirebaseAuth.instance.currentUser!.linkWithCredential(
                PhoneAuthProvider.credential(
                  verificationId: storedVerificationId,
                  smsCode:
                      (await emulatorPhoneVerificationCode(testPhoneNumber))!,
                ),
              );
              expect(FirebaseAuth.instance.currentUser, equals(isA<User>()));
              expect(
                FirebaseAuth.instance.currentUser!.phoneNumber,
                equals(testPhoneNumber),
              );
              expect(
                FirebaseAuth.instance.currentUser!.providerData,
                equals(isA<List<UserInfo>>()),
              );
              expect(
                FirebaseAuth.instance.currentUser!.providerData.length,
                equals(1),
              );
              expect(
                FirebaseAuth.instance.currentUser!.providerData[0],
                equals(isA<UserInfo>()),
              );
              expect(FirebaseAuth.instance.currentUser!.isAnonymous, isFalse);
              await FirebaseAuth.instance.currentUser
                  ?.unlink(PhoneAuthProvider.PROVIDER_ID);
              await FirebaseAuth.instance.currentUser?.delete();
            },
            skip: kIsWeb ||
                defaultTargetPlatform == TargetPlatform.macOS ||
                defaultTargetPlatform == TargetPlatform.windows,
          ); // verifyPhoneNumber not supported on web.

          test(
            'should error on link anonymous account <-> phone account if invalid credentials',
            () async {
              // Setup
              await FirebaseAuth.instance.signInAnonymously();

              try {
                await FirebaseAuth.instance.currentUser!.linkWithCredential(
                  PhoneAuthProvider.credential(
                    verificationId: 'test',
                    smsCode: 'test',
                  ),
                );
              } on FirebaseAuthException catch (e) {
                expect(e.code, equals('invalid-verification-id'));
                expect(
                  e.message,
                  equals(
                    'The verification ID used to create the phone auth credential is invalid.',
                  ),
                );
                return;
              } catch (e) {
                fail('should have thrown an FirebaseAuthException');
              }

              fail('should have thrown an error');
            },
            skip: defaultTargetPlatform == TargetPlatform.macOS ||
                defaultTargetPlatform == TargetPlatform.windows,
          );
        },
        skip: !kIsWeb &&
            (defaultTargetPlatform == TargetPlatform.windows ||
                defaultTargetPlatform == TargetPlatform.macOS),
      );

      group(
        'reauthenticateWithCredential()',
        () {
          test('should reauthenticate correctly', () async {
            // Setup
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            final initialUser = FirebaseAuth.instance.currentUser;

            // Test
            AuthCredential credential = EmailAuthProvider.credential(
              email: email,
              password: testPassword,
            );
            await FirebaseAuth.instance.currentUser!
                .reauthenticateWithCredential(credential);

            // Assertions
            final currentUser = FirebaseAuth.instance.currentUser;
            expect(currentUser, isNot(equals(null)));
            expect(initialUser, isNot(equals(null)));
            expect(currentUser?.email, equals(email));
            expect(currentUser?.uid, equals(initialUser?.uid));
          });

          test('should throw user-mismatch ', () async {
            // Setup
            String emailAlready = generateRandomEmail();

            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );

            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: emailAlready,
              password: testPassword,
            );

            try {
              // Test
              AuthCredential credential = EmailAuthProvider.credential(
                email: email,
                password: testPassword,
              );
              await FirebaseAuth.instance.currentUser!
                  .reauthenticateWithCredential(credential);
            } on FirebaseAuthException catch (e) {
              // Assertions
              expect(e.code, equals('user-mismatch'));
              expect(
                e.message,
                anyOf(
                  equals(
                    'The supplied credentials do not correspond to the previously signed in user.',
                  ),
                  // Windows C++ SDK omits the trailing period.
                  equals(
                    'The supplied credentials do not correspond to the previously signed in user',
                  ),
                ),
              );
              await FirebaseAuth.instance.currentUser!.delete(); //clean up
              return;
            } catch (e) {
              fail('should have thrown an FirebaseAuthException');
            }

            fail('should have thrown an error');
          });

          test('should throw user-not-found or user-mismatch ', () async {
            // Setup
            final userCredential =
                await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            final user = userCredential.user;

            try {
              // Test
              AuthCredential credential = EmailAuthProvider.credential(
                email: 'userdoesnotexist@foobar.com',
                password: testPassword,
              );
              await user!.reauthenticateWithCredential(credential);
            } on FirebaseAuthException catch (e) {
              // Platforms throw different errors. For now, leave them as is
              // but in future we might want to edit them before sending to user.
              if (e.code != 'user-mismatch' && e.code != 'user-not-found') {
                fail('should have thrown a valid error code (got ${e.code}');
              }

              return;
            } catch (e) {
              fail('should have thrown an FirebaseAuthException');
            }

            fail('should have thrown an error');
          });

          test('should throw wrong-password ', () async {
            // Setup
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );

            try {
              // Test
              AuthCredential credential = EmailAuthProvider.credential(
                email: email,
                password: 'WRONG_testPassword',
              );
              await FirebaseAuth.instance.currentUser!
                  .reauthenticateWithCredential(credential);
            } on FirebaseAuthException catch (e) {
              // Assertions
              expect(e.code, equals('wrong-password'));
              expect(
                e.message,
                equals(
                  'The password is invalid or the user does not have a password.',
                ),
              );
              return;
            } catch (e) {
              fail('should have thrown an FirebaseAuthException');
            }

            fail('should have thrown an error');
          });

          test(
            'should throw wrong-password ',
            () async {
              // Setup
              final email = generateRandomEmail();
              await FirebaseAuth.instance.createUserWithEmailAndPassword(
                email: email,
                password: testPassword,
              );

              await FirebaseAuth.instance.signOut();

              await expectLater(
                FirebaseAuth.instance.signInWithEmailAndPassword(
                  email: email,
                  password: 'wrong password',
                ),
                throwsA(
                  isA<FirebaseAuthException>()
                      .having((e) => e.code, 'code', equals('wrong-password'))
                      .having(
                        (e) => e.message,
                        'message',
                        equals(
                          'The password is invalid or the user does not have a password.',
                        ),
                      ),
                ),
              );
            },
            // Exercises signInWithEmailAndPassword, not reauthenticateWithCredential.
            // A test-level skip overrides the group skip, so include macOS here too.
            skip: !kIsWeb &&
                (defaultTargetPlatform == TargetPlatform.windows ||
                    defaultTargetPlatform == TargetPlatform.macOS),
          );
        },
        skip: !kIsWeb && defaultTargetPlatform == TargetPlatform.macOS,
      );

      group('reload()', () {
        test('should not error', () async {
          await FirebaseAuth.instance.signInAnonymously();
          try {
            await FirebaseAuth.instance.currentUser!.reload();
            await FirebaseAuth.instance.signOut();
          } catch (e) {
            fail('should not throw error');
          }
          expect(FirebaseAuth.instance.currentUser, isNull);
        });

        test(
          'should preserve photoURL after reload',
          () async {
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            await FirebaseAuth.instance.currentUser!.updatePhotoURL(
              'http://photo.url/test.jpg',
            );
            await FirebaseAuth.instance.currentUser!.reload();

            expect(
              FirebaseAuth.instance.currentUser!.photoURL,
              'http://photo.url/test.jpg',
            );

            // Reload again to exercise the PigeonParser path
            // with a non-null photoURL
            await FirebaseAuth.instance.currentUser!.reload();

            expect(
              FirebaseAuth.instance.currentUser!.photoURL,
              'http://photo.url/test.jpg',
            );
            expect(
              FirebaseAuth.instance.currentUser!.displayName,
              isNull,
            );
          },
          skip: kIsWeb ||
              defaultTargetPlatform == TargetPlatform.macOS ||
              defaultTargetPlatform == TargetPlatform.windows,
        );

        test(
          'should handle reload when photoURL is null',
          () async {
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );

            // User created without photoURL — reload should not crash
            await FirebaseAuth.instance.currentUser!.reload();

            expect(
              FirebaseAuth.instance.currentUser!.photoURL,
              isNull,
            );
          },
          skip: kIsWeb ||
              defaultTargetPlatform == TargetPlatform.macOS ||
              defaultTargetPlatform == TargetPlatform.windows,
        );
      });

      group(
        'sendEmailVerification()',
        () {
          test('should not error', () async {
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: generateRandomEmail(),
              password: testPassword,
            );
            try {
              await FirebaseAuth.instance.currentUser!.sendEmailVerification();
            } catch (e) {
              fail('should not throw error');
            }
            expect(FirebaseAuth.instance.currentUser, isNotNull);
          });

          test(
            'should work with actionCodeSettings',
            () async {
              // Setup
              ActionCodeSettings actionCodeSettings = ActionCodeSettings(
                handleCodeInApp: true,
                url: 'https://flutterfire-e2e-tests.firebaseapp.com/foo',
              );
              await FirebaseAuth.instance.createUserWithEmailAndPassword(
                email: generateRandomEmail(),
                password: testPassword,
              );

              // Test
              try {
                await FirebaseAuth.instance.currentUser!
                    .sendEmailVerification(actionCodeSettings);
              } catch (error) {
                fail('$error');
              }
              expect(FirebaseAuth.instance.currentUser, isNotNull);
            },
            // macOS skipped because it needs keychain sharing entitlement. See: https://github.com/firebase/flutterfire/issues/9538
            skip: kIsWeb ||
                defaultTargetPlatform == TargetPlatform.macOS ||
                defaultTargetPlatform == TargetPlatform.windows,
          );
        },
        skip: !kIsWeb &&
            (defaultTargetPlatform == TargetPlatform.windows ||
                defaultTargetPlatform == TargetPlatform.macOS),
      );

      group(
        'unlink()',
        () {
          test('should unlink the email address', () async {
            // Setup
            await FirebaseAuth.instance.signInAnonymously();

            AuthCredential credential = EmailAuthProvider.credential(
              email: email,
              password: testPassword,
            );
            await FirebaseAuth.instance.currentUser!
                .linkWithCredential(credential);

            // verify user is linked
            final linkedUser = FirebaseAuth.instance.currentUser;
            expect(linkedUser?.email, email);
            expect(linkedUser?.providerData, isA<List<UserInfo>>());
            expect(linkedUser?.providerData.length, equals(1));

            // Test
            await FirebaseAuth.instance.currentUser!
                .unlink(EmailAuthProvider.PROVIDER_ID);

            // Assertions
            final unlinkedUser = FirebaseAuth.instance.currentUser;
            expect(unlinkedUser?.providerData, isA<List<UserInfo>>());
            expect(unlinkedUser?.providerData.length, equals(0));
          });

          test('should throw error if provider id given does not exist',
              () async {
            // Setup
            await FirebaseAuth.instance.signInAnonymously();

            AuthCredential credential = EmailAuthProvider.credential(
              email: email,
              password: testPassword,
            );
            await FirebaseAuth.instance.currentUser!
                .linkWithCredential(credential);

            // verify user is linked
            final linkedUser = FirebaseAuth.instance.currentUser;
            expect(linkedUser?.email, email);

            // Test
            try {
              await FirebaseAuth.instance.currentUser!.unlink('invalid');
            } on FirebaseAuthException catch (e) {
              expect(e.code, 'no-such-provider');
              expect(
                e.message,
                'User was not linked to an account with the given provider.',
              );
              return;
            } catch (e) {
              fail('should have thrown an FirebaseAuthException error');
            }
            fail('should have thrown an error');
          });

          test('should throw error if user does not have this provider linked',
              () async {
            // Setup
            await FirebaseAuth.instance.signInAnonymously();
            // Test
            try {
              await FirebaseAuth.instance.currentUser!
                  .unlink(EmailAuthProvider.PROVIDER_ID);
            } on FirebaseAuthException catch (e) {
              expect(e.code, 'no-such-provider');
              expect(
                e.message,
                'User was not linked to an account with the given provider.',
              );
              return;
            } catch (e) {
              fail('should have thrown an FirebaseAuthException error');
            }
            fail('should have thrown an error');
          });
        },
        skip: !kIsWeb &&
            (defaultTargetPlatform == TargetPlatform.windows ||
                defaultTargetPlatform == TargetPlatform.macOS),
      );

      group(
        'updatePassword()',
        () {
          test('should update the password', () async {
            String pass = '${testPassword}1';
            String pass2 = '${testPassword}2';
            // Setup
            await FirebaseAuth.instance
                .createUserWithEmailAndPassword(email: email, password: pass);

            // Update user password
            await FirebaseAuth.instance.currentUser!.updatePassword(pass2);

            // // Sign out
            await FirebaseAuth.instance.signOut();

            // Log in with the new password
            await FirebaseAuth.instance
                .signInWithEmailAndPassword(email: email, password: pass2);

            // Assertions
            expect(FirebaseAuth.instance.currentUser, isA<Object>());
            expect(FirebaseAuth.instance.currentUser!.email, equals(email));
          });
          test('should throw error if password is weak', () async {
            // Setup
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );

            // Test
            try {
              // Update user password
              await FirebaseAuth.instance.currentUser!.updatePassword('weak');
            } on FirebaseAuthException catch (e) {
              expect(e.code, 'weak-password');
              expect(e.message, 'Password should be at least 6 characters');
              return;
            } catch (e) {
              fail('should have thrown an FirebaseAuthException error');
            }
            fail('should have thrown an error');
          });
        },
        skip: !kIsWeb &&
            (defaultTargetPlatform == TargetPlatform.windows ||
                defaultTargetPlatform == TargetPlatform.macOS),
      );

      group(
        'refreshToken',
        () {
          test(
            'should throw an unsupported error on non web platforms',
            () async {
              // Setup
              await FirebaseAuth.instance.signInAnonymously();

              // Test
              FirebaseAuth.instance.currentUser!.refreshToken;

              // Assertions
              expect(
                FirebaseAuth.instance.currentUser!.refreshToken,
                isNull,
              );
            },
            // macOS skipped because it needs keychain sharing entitlement. See: https://github.com/firebase/flutterfire/issues/9538
            // iOS supports it
            skip: kIsWeb ||
                defaultTargetPlatform == TargetPlatform.macOS ||
                defaultTargetPlatform == TargetPlatform.iOS,
          );

          test(
            'should return a token on web',
            () async {
              // Setup
              await FirebaseAuth.instance.signInAnonymously();

              // Test
              FirebaseAuth.instance.currentUser!.refreshToken;

              // Assertions
              expect(
                FirebaseAuth.instance.currentUser!.refreshToken,
                isA<String>(),
              );
              expect(
                FirebaseAuth.instance.currentUser!.refreshToken!.isEmpty,
                isFalse,
              );
            },
            skip: !kIsWeb,
          );
        },
        skip: !kIsWeb && defaultTargetPlatform == TargetPlatform.windows,
      );

      group(
        'user.metadata',
        () {
          test(
              "should have the properties 'lastSignInTime' & 'creationTime' which are ISO strings",
              () async {
            // Setup
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: generateRandomEmail(),
              password: testPassword,
            );
            final user = FirebaseAuth.instance.currentUser;

            // Test
            final metadata = user?.metadata;

            // Assertions
            expect(metadata?.lastSignInTime, isA<DateTime>());
            expect(metadata?.lastSignInTime!.year, DateTime.now().year);
            expect(metadata?.creationTime, isA<DateTime>());
            expect(metadata?.creationTime!.year, DateTime.now().year);
          });
        },
        skip: !kIsWeb &&
            (defaultTargetPlatform == TargetPlatform.windows ||
                defaultTargetPlatform == TargetPlatform.macOS),
      );

      group('updateDisplayName', () {
        test('updates the user displayName without impacting the photoURL',
            () async {
          // First create a user with a photo
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
            email: email,
            password: testPassword,
          );
          await FirebaseAuth.instance.currentUser!
              .updateDisplayName('Mona Lisa');
          await FirebaseAuth.instance.currentUser!.updatePhotoURL(
            'http://photo.url/test.jpg',
          );
          await FirebaseAuth.instance.currentUser!.reload();

          expect(
            FirebaseAuth.instance.currentUser!.photoURL,
            'http://photo.url/test.jpg',
          );
          expect(
            FirebaseAuth.instance.currentUser!.displayName,
            'Mona Lisa',
          );

          await FirebaseAuth.instance.currentUser!
              .updateDisplayName('John Smith');
          await FirebaseAuth.instance.currentUser!.reload();

          expect(
            FirebaseAuth.instance.currentUser!.photoURL,
            'http://photo.url/test.jpg',
          );
          expect(
            FirebaseAuth.instance.currentUser!.displayName,
            'John Smith',
          );
        });

        test(
          'can set the displayName to null',
          () async {
            // First create a user with a photo
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            await FirebaseAuth.instance.currentUser!
                .updateDisplayName('Mona Lisa');
            await FirebaseAuth.instance.currentUser!.reload();

            // Just checking that the user indeed had a name before we set it to null
            expect(
              FirebaseAuth.instance.currentUser!.displayName,
              isNotNull,
            );

            await FirebaseAuth.instance.currentUser!.updateDisplayName(null);
            await FirebaseAuth.instance.currentUser!.reload();

            expect(
              FirebaseAuth.instance.currentUser!.displayName,
              isNull,
            );
            // Skip apple CI because of https://github.com/firebase/firebase-ios-sdk/issues/8149
            // Using `kIsWeb` because `Platform` is not available on web
          },
          // setting `displayName` on web throws an error
          skip: kIsWeb ||
              defaultTargetPlatform == TargetPlatform.iOS ||
              defaultTargetPlatform == TargetPlatform.macOS ||
              defaultTargetPlatform == TargetPlatform.windows,
        );
      });

      group(
        'updatePhotoURL',
        () {
          test('updates the photoURL without impacting the displayName',
              () async {
            // First create a user with a photo
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            await Future.wait([
              FirebaseAuth.instance.currentUser!.updateDisplayName('Mona Lisa'),
              FirebaseAuth.instance.currentUser!.updatePhotoURL(
                'http://photo.url/test.jpg',
              ),
            ]);
            await FirebaseAuth.instance.currentUser!.reload();

            expect(
              FirebaseAuth.instance.currentUser!.photoURL,
              'http://photo.url/test.jpg',
            );
            expect(
              FirebaseAuth.instance.currentUser!.displayName,
              'Mona Lisa',
            );

            await FirebaseAuth.instance.currentUser!.updatePhotoURL(
              'http://photo.url/dash.jpg',
            );
            await FirebaseAuth.instance.currentUser!.reload();

            expect(
              FirebaseAuth.instance.currentUser!.photoURL,
              'http://photo.url/dash.jpg',
            );
            expect(
              FirebaseAuth.instance.currentUser!.displayName,
              'Mona Lisa',
            );
          });

          test(
            'can set the photoURL to null',
            () async {
              // First create a user with a photo
              await FirebaseAuth.instance.createUserWithEmailAndPassword(
                email: email,
                password: testPassword,
              );
              await FirebaseAuth.instance.currentUser!.updatePhotoURL(
                'http://photo.url/test.jpg',
              );
              await FirebaseAuth.instance.currentUser!.reload();

              // Just checking that the user indeed had a photo before we set it to null
              expect(
                FirebaseAuth.instance.currentUser!.photoURL,
                isNotNull,
              );

              await FirebaseAuth.instance.currentUser!.updatePhotoURL(null);
              await FirebaseAuth.instance.currentUser!.reload();

              expect(
                FirebaseAuth.instance.currentUser!.photoURL,
                isNull,
              );
            },
            // setting `photoURL` on web throws an error
            // macOS skipped because it needs keychain sharing entitlement. See: https://github.com/firebase/flutterfire/issues/9538
            skip: kIsWeb ||
                defaultTargetPlatform == TargetPlatform.macOS ||
                defaultTargetPlatform == TargetPlatform.windows,
          );
        },
      );

      group('updatePhoneNumber()', () {
        test(
          'should throw an FirebaseAuthException if verification id is invalid',
          () async {
            // Setup
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );

            try {
              // Update user profile
              await FirebaseAuth.instance.currentUser!.updatePhoneNumber(
                PhoneAuthProvider.credential(
                  verificationId: 'invalid',
                  smsCode: '123456',
                ),
              );
            } on FirebaseAuthException catch (e) {
              expect(e.code, 'invalid-verification-id');
              expect(
                e.message,
                'The verification ID used to create the phone auth credential is invalid.',
              );
              return;
            } catch (e) {
              fail('should have thrown a AssertionError error');
            }

            fail('should have thrown an error');
          },
          skip: kIsWeb ||
              defaultTargetPlatform == TargetPlatform.macOS ||
              defaultTargetPlatform == TargetPlatform.windows,
        );
      });

      group(
        'delete()',
        () {
          test('should delete a user', () async {
            // Setup
            UserCredential userCredential =
                await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            final user = userCredential.user;

            // Test
            await user?.delete();

            // Assertions
            expect(FirebaseAuth.instance.currentUser, equals(null));
            await FirebaseAuth.instance
                .createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            )
                .then((UserCredential userCredential) {
              expect(FirebaseAuth.instance.currentUser!.email, equals(email));
              return;
            }).catchError((Object error) {
              fail('Should have successfully created user after deletion');
            });
          });

          test('should throw an error on delete when no user is signed in',
              () async {
            // Setup
            UserCredential userCredential =
                await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email,
              password: testPassword,
            );
            final user = userCredential.user;

            await FirebaseAuth.instance.signOut();

            try {
              // Test
              await user!.delete();
            } on FirebaseAuthException catch (e) {
              // Assertions
              expect(e.code, 'no-current-user');
              expect(e.message, 'No user currently signed in.');

              return;
            } catch (e) {
              fail('Should have thrown an FirebaseAuthException error');
            }

            fail('Should have thrown an error');
          });
        },
        skip: !kIsWeb &&
            (defaultTargetPlatform == TargetPlatform.windows ||
                defaultTargetPlatform == TargetPlatform.macOS),
      );
    },
    // macOS skipped because it needs keychain sharing entitlement. See: https://github.com/firebase/flutterfire/issues/9538
    skip: defaultTargetPlatform == TargetPlatform.macOS,
  );
}
